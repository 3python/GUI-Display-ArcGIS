import arcpy
import pythonaddins

class RiskButton(object):
    """Implementation for crime_addin.RiskButton (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.MessageBox("Hello world", "Hello")
        pythonaddins.GPToolDialog("m:/Python_Advanced/albertsurface/Models.tbx", "CrimeScript")
