import arcpy

#Set the filepath of the location to work at.
arcpy.env.workspace = "C:/"

#If the name of the file that you want to create exists, overwrite it.
if arcpy.Exists("crime.shp"):
    arcpy.Delete_management ("crime.shp")

#Set the parameters that you want the user to enter.
Burglaries = arcpy.GetParameterAsText(0)
Distance = arcpy.GetParameterAsText(1)
Buildings = arcpy.GetParameterAsText(2)
#need to change the output so that it overwrites a current output of the same name.

Out = "crime.shp"

#Set the path that the toolbox is located.
#This is on the C drive of my personal computer so I have deleted the path.
arcpy.ImportToolbox("C:/Users/kate.../Models.tbx", "models")
#Then import the name of the tooxbox.
#Include the parameters that the toolbox should ask the user for.
arcpy.TraffordModel_models(Burglaries, Distance, Out, Buildings)

#TraffordModelScript.py:
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame 
newlayer = arcpy.mapping.Layer("crime.shp")
layerFile = arcpy.mapping.Layer("albertsquare/buildings.lyr")
arcpy.mapping.UpdateLayer(df, newlayer, layerFile, True)
newlayer.symbology.valueField = "Join_Count"
newlayer.symbology.addAllValues() 
arcpy.mapping.AddLayer(df, newlayer,"TOP")
